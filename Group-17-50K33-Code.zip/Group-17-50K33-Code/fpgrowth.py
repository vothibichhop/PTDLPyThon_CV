import sys
import subprocess

try:
    import pandas as pd
    from mlxtend.frequent_patterns import fpgrowth, association_rules
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "mlxtend"])
    import pandas as pd
    from mlxtend.frequent_patterns import fpgrowth, association_rules

print("Packages loaded successfully.")

import pandas as pd  

# Tải tập dữ liệu giao dịch đã được mã hóa
# File Data_Encoded.csv nằm cùng thư mục với file python hiện tại.
df = pd.read_csv('Data_Encoded.csv')

print('Dataset shape:', df.shape)
print(df.head())
print(df.dtypes)

# Loại bỏ cột đầu tiên nếu đó là cột hóa đơn hoặc cột chỉ mục
df = df.iloc[:, 1:]
# Chuyển tất cả các giá trị về dạng boolean để sử dụng cho thuật toán FP-Growth.
df = (df > 0).astype(bool)
print('Processed shape: ', df.shape)
print(df.head())


# Chạy thuật toán FP-Growth
frequent_itemsets = fpgrowth(df, min_support=0.005, use_colnames=True)
frequent_itemsets = frequent_itemsets.sort_values(by='support', ascending=False)
print('== Frequent Itemsets ==')
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
print(frequent_itemsets)
pd.reset_option('display.max_rows')
pd.reset_option('display.max_columns')
pd.reset_option('display.width')


# Sinh các luật kết hợp từ tất cả các tập mục phổ biến.
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.05)
print('Total rules generated:', len(rules))
print(rules.head())


# Lọc các luật kết hợp nhiều sản phẩm
rules_multi = rules[(rules['antecedents'].apply(lambda x: len(x) >= 2)) | (rules['consequents'].apply(lambda x: len(x) >= 2))]
rules_multi = rules_multi.sort_values(by='confidence', ascending=False)
print('=== Association Rules from 2+ Products ===')
print('Total multi-product rules:', len(rules_multi))
if len(rules_multi) > 0:
    print('===Top 5 multi-product rules:')
    top_5 = rules_multi.head(5)
    for i, (_, row) in enumerate(top_5.iterrows(), 1):
        print(f"\n{i}. IF {list(row['antecedents'])}")
        print(f" THEN {list(row['consequents'])}")
        print(f" Support: {row['support']:.4f}, Confidence: {row['confidence']:.4f}, Lift: {row['lift']:.2f}")