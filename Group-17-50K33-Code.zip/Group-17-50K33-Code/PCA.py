import pandas as nd
import numpy as np

form sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

#up, đọc & kiểm tra cấu trúc dữ liệu
from google.colab import files
uploaded = files.upload()

df=pd.read_excel ("data_no_outliers.xlsx")
df.head()
df.info()
df.describe()

#chuyển đổi dữ liệu UnitPrice & TotalPrice sang dạng số
df["UnitPrice"]= pd.to_numeric(df["UnitPrice"], errors="coerce")
df["TotalPrice"]= pd.to_numeric(df["TotalPrice"], errors="coerce")

#kiểm tra & loại bỏ dữ liệu thiếu
df[["UnitPrice", "TotalPrice"]].isnull().sum()
df=df.dropna()

#Chọn các thuộc tính numerical để phân tích PCA
numeric_df = df.select_dtypes(include=[np.number])
print("Số cột numeric:", numeric_df.shape[1])
print("Số dòng:", numeric_df.shape[0])

#Chuẩn hóa dữ liệu bằng StandardScaler
scaler = StandardScaler()
scaled_data = scaler.fit_transform(numeric_df)

#Thực hiện PCA và tính Explained Variance
pca = PCA()
pca_data = pca.fit_transform(scaled_data)

explained_variance = pca.explained_variance_ratio_
# In variance từng PC
for i, var in enumerate(explained_variance):
    print(f"PC{i+1}: {var:.4f}")
    
#Vẽ biểu đồ Scree Plot
plt.figure(figsize=(10,6))
plt.plot(np.cumsum(explained_variance), marker='o')
plt.xlabel("Số lượng Principal Components")
plt.ylabel("Tổng phương sai giải thích (Cumulative Explained Variance)")
plt.title("Biểu đồ Scree Plot - PCA")
plt.grid(True)
plt.show()

#Chạy PCA với ngưỡng giữ lại 95% phương sai
pca_95 = PCA(n_components=0.95)
pca_reduced = pca_95.fit_transform(scaled_data)

print("Số chiều sau PCA:", pca_reduced.shape[1])

#Tạo DataFrame PCA và ghép với dữ liệu gốc
pca_df = pd.DataFrame(pca_reduced)
pca_df.columns = [f"PC{i+1}" for i in range(pca_df.shape[1])]

final_df = pd.concat([df.reset_index(drop=True), pca_df], axis=1)
final_df.head()

#Xuất file kết quả và trực quan hóa PCA 2D
final_df.to_excel("data_after_PCA.xlsx", index=False)
print("Đã lưu file data_after_PCA.xlsx")

files.download("data_after_PCA.xlsx")
#bieuer ddoof scatter plot pca 2 chieuef
pca_2 = PCA(n_components=2)
pca_2_data = pca_2.fit_transform(scaled_data)

plt.figure(figsize=(10,6))
plt.scatter(pca_2_data[:,0], pca_2_data[:,1], s=1)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("Biểu diễn dữ liệu sau PCA (2 chiều)")
plt.grid(True)
plt.show()