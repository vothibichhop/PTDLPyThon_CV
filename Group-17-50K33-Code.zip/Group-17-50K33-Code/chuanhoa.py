# =====Vẽ biểu đồ phân phối dữ liệu gốc
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# Đọc dữ liệu đã xử lý
data = pd.read_csv('data_no_outliers_1.csv')
# Chọn cột cần vẽ
cols = ['Quantity', 'UnitPrice', 'TotalPrice']
# Thiết lập figure
plt.figure(figsize=(10,6))
# Vẽ boxplot, tắt hiển thị outliers
sns.boxplot(data=data[cols], palette="Set2", showfliers=False)
# Thêm tiêu đề và nhãn
plt.title('Boxplot of Quantity, UnitPrice, TotalPrice', fontsize=14)
plt.xlabel('Variables', fontsize=12)
plt.ylabel('Value', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.3)
# Hiển thị biểu đồ
plt.show()

#=== Code chuẩn hóa bằng Min-Max
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# Đọc dữ liệu
data = pd.read_csv('data_no_outliers_1.csv')
# Chọn cột cần chuẩn hóa
cols = ['Quantity', 'UnitPrice', 'TotalPrice']
# Chuẩn hóa Min-Max và ghi đè
for col in cols:
    min_val = data[col].min()
    max_val = data[col].max()
    data[col] = (data[col] - min_val) / (max_val - min_val)
# Lưu tất cả các cột, 3 cột đã chuẩn hóa
data.to_csv('data_all_scaled.csv', index=False)
# --- VẼ BOXPLOT sau chuẩn hóa ---
plt.figure(figsize=(10,6))
sns.boxplot(data=data[cols], palette="Set2", showfliers=False)  # ẩn outliers
plt.title('Boxplot of Quantity, UnitPrice, TotalPrice (After Min-Max Scaling)', fontsize=14)
plt.xlabel('Variables', fontsize=12)
plt.ylabel('Scaled Value', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.3)
plt.show()


# ======Code chuẩn hóa bằng Z-score
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# --- Đọc dữ liệu ---
data = pd.read_csv('data_no_outliers_1.csv')
# Các cột cần chuẩn hóa
cols = ['Quantity', 'UnitPrice', 'TotalPrice']
# --- Chuẩn hóa Z-score và ghi đè ---
for col in cols:
    mean_val = data[col].mean()
    std_val = data[col].std()
    data[col] = (data[col] - mean_val) / std_val
# --- Xem 5 dòng đầu sau chuẩn hóa ---
print("5 dòng đầu sau chuẩn hóa Z-score:")
print(data.head())
# --- Lưu tất cả các cột, 3 cột đã chuẩn hóa ---
data.to_csv('data_all_zscore.csv', index=False)

# --- VẼ BOXPLOT sau chuẩn hóa ---
plt.figure(figsize=(10,6))
sns.boxplot(data=data[cols], palette="Set2", showfliers=False) # ẩn outliers
plt.title('Boxplot of Quantity, UnitPrice, TotalPrice (After Z-score Scaling)', fontsize=14)
plt.xlabel('Variables', fontsize=12)
plt.ylabel('Z-score Value', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.3)
plt.show()