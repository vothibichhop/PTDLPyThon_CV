#======Code nhận diện outlier bằng Z-score
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import zscore, norm
import pandas as pd

# 1. Đọc dữ liệu
df = pd.read_csv("data_cleaned.csv")
cols = ['Quantity', 'UnitPrice', 'TotalPrice']

plt.figure(figsize=(20, 6))

for i, col in enumerate(cols):
    plt.subplot(1, 3, i+1)
    
    data = pd.to_numeric(df[col], errors='coerce').dropna()
    data = data[data > 0]
    
    # Tính Z-score
    z = zscore(data)
    n_outliers = np.sum(np.abs(z) > 3)
    
    plt.hist(z, bins=1000, density=True, alpha=0.5, color='steelblue', label='Dữ liệu thực tế')
    
    x_pdf = np.linspace(-4, 4, 200)
    plt.plot(x_pdf, norm.pdf(x_pdf, 0, 1), 'r-', lw=3, label='PDF chuẩn')
    
    plt.xlim(-2, 4)
    
    # Vẽ ngưỡng Z=3
    plt.axvline(3, color='darkorange', linestyle='--', lw=2)
    plt.axvline(-3, color='darkorange', linestyle='--')
    
    plt.title(f'{col}\nOutliers: {n_outliers}', fontweight='bold')
    plt.legend()

plt.tight_layout()
plt.show()

#======= Code xử lý outlier bằng Z-score
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import zscore, norm
import pandas as pd

# Đọc dữ liệu
df = pd.read_csv("data_cleaned.csv")
cols = ['Quantity', 'UnitPrice', 'TotalPrice']

# ===== LOẠI OUTLIER =====
df_cleaned = df.copy()
z_scores = np.abs(zscore(df_cleaned[cols].apply(pd.to_numeric, errors='coerce')))
df_cleaned = df_cleaned[(z_scores <= 3).all(axis=1)]

# ===== VẼ BIỂU ĐỒ SAU KHI LỌC =====
plt.figure(figsize=(20, 6))

for i, col in enumerate(cols):
    plt.subplot(1, 3, i+1)
    
    data = pd.to_numeric(df_cleaned[col], errors='coerce').dropna()
    z = zscore(data)
    
    # Histogram
    plt.hist(z, bins=50, density=True, alpha=0.6, color='forestgreen', edgecolor='white')
    
    # Đường chuẩn
    x = np.linspace(-4, 4, 200)
    plt.plot(x, norm.pdf(x, 0, 1), 'r-', lw=2)
    
    # Ngưỡng Z
    plt.axvline(3, linestyle='--')
    plt.axvline(-3, linestyle='--')
    
    plt.title(f'{col} (After)')
    plt.xlim(-4, 4)

plt.suptitle("PHÂN PHỐI SAU KHI LOẠI NGOẠI LAI (Z-SCORE)", fontsize=14)
plt.tight_layout()
plt.show()

# Lưu file
df_cleaned.to_csv("data_cleaned_no_outliers.csv", index=False)

# === Code hồi quy tuyến tính và kiểm định F-test
import pandas as pd
import statsmodels.api as sm

# Đọc dữ liệu
df = pd.read_csv("data_cleaned.csv")

df = df[(df['Quantity'] > 0) & (df['TotalPrice'] > 0)]
df = df[df['Quantity'] < 50000]

# Chọn biến
X = df[['Quantity', 'UnitPrice']].apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(df['TotalPrice'], errors='coerce')

# Bỏ NaN
data = pd.concat([X, y], axis=1).dropna()
X = data[['Quantity', 'UnitPrice']]
y = data['TotalPrice']

# Thêm hệ số chặn
X = sm.add_constant(X)

# Hồi quy
model = sm.OLS(y, X).fit()

# Kết quả
print(model.summary())

#===== Biểu đồ hồi quy tuyến tính của dữ liệu gốc
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(6,5))
sns.regplot(x='Quantity', y='TotalPrice', data=df)

plt.title("Hồi quy giữa Quantity và TotalPrice (Dữ liệu gốc)")
plt.xlabel("Quantity")
plt.ylabel("TotalPrice")
plt.show()

plt.figure(figsize=(6,5))
sns.regplot(x='UnitPrice', y='TotalPrice', data=df)

plt.title("Hồi quy giữa UnitPrice và TotalPrice (Dữ liệu gốc)")
plt.xlabel("UnitPrice")
plt.ylabel("TotalPrice")
plt.show()

#==== Code phát hiện và xử lý giá trị ngoại lai bằng hồi quy tuyến tính
import numpy as np
# ===== DỰ ĐOÁN =====
y_pred = model.predict(X)
# ===== TÍNH RESIDUAL =====
residual = y - y_pred
# ===== NGƯỠNG =====
threshold = 2 * residual.std()
# ===== PHÁT HIỆN + XỬ LÝ =====
data['is_outlier'] = np.abs(residual) > threshold
# Tạo dữ liệu sau xử lý
data_cleaned = data.copy()
data_cleaned.loc[data['is_outlier'], 'TotalPrice'] = y_pred[data['is_outlier']]
# In kết quả
print("Số outlier:", data['is_outlier'].sum())

#=====Vẽ lại biểu đồ sau khi xử lý outlier
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(6,5))
sns.regplot(x='Quantity', y='TotalPrice', data=data_cleaned)

plt.title("Sau xử lý: Quantity vs TotalPrice")
plt.xlabel("Quantity")
plt.ylabel("TotalPrice")
plt.show()

plt.figure(figsize=(6,5))
sns.regplot(x='UnitPrice', y='TotalPrice', data=data_cleaned)

plt.title("Sau xử lý: UnitPrice vs TotalPrice")
plt.xlabel("UnitPrice")
plt.ylabel("TotalPrice")
plt.show()